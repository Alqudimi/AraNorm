## Summary

<!-- Describe what this PR does and why. Link to the issue it resolves. -->

Closes #<!-- issue number -->

---

## Changes

<!-- List the key changes made in this PR. -->

- 
- 
- 

---

## Type of Change

- [ ] 🐛 Bug fix (non-breaking change that fixes an issue)
- [ ] ✨ New feature (non-breaking change that adds functionality)
- [ ] 💥 Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] 📝 Documentation update
- [ ] 🔧 Refactor / code quality (no behavior change)
- [ ] ⚡ Performance improvement
- [ ] 🔒 Security fix
- [ ] 🏗️ CI/CD / build system change

---

## Testing

<!-- Describe how you tested your changes. -->

- [ ] New unit tests added
- [ ] Existing tests pass locally (`python -m pytest`)
- [ ] Coverage is maintained or improved

```bash
python -m pytest tests/ -v
# test output here
```

---

## Checklist

- [ ] Code follows the [Style Guide](../STYLE_GUIDE.md)
- [ ] All public functions/methods have docstrings with an `Example`
- [ ] Type annotations are complete
- [ ] `CHANGELOG.md` updated under `[Unreleased]`
- [ ] No new lint errors (`flake8 src/`)
- [ ] No new type errors (`mypy src/aranorm/`)
- [ ] No hardcoded secrets or credentials

---

## Screenshots / Output (if applicable)

<!-- Add before/after output, test results, or any other relevant artifacts. -->
