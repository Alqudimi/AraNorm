"""Test fixtures for AraNorm."""
